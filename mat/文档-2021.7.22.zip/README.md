查看文档

tar vxzf gatewar.tar.gz 
cd  public

Python2:
python -m SimpleHTTPServer 8000


Python3:
python -m http.server 8000 --bind 127.0.0.1
